<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="STS" />
        <meta name="author" content="STS" />
        <title><?php echo e($data['title']); ?></title>
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />
        <script src="<?php echo e(asset('js/jquery-3.5.1.js')); ?>"></script>
        <script src="<?php echo e(asset('js/fontawesome.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('assets/demo/chart-area-demo.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/demo/chart-bar-demo.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
        <link rel="stylesheet" href="<?php echo e(asset('css/jquery.dataTables.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/fixedHeader.bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap.min.css')); ?>">
        <script src="<?php echo e(asset('js/dataTables.fixedHeader.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/responsive.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/dataTables.buttons.min.js')); ?>"></script>
        <link rel="stylesheet" href="<?php echo e(asset('css/buttons.dataTables.min.css')); ?>">
        <script src="<?php echo e(asset('js/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/buttons.print.min.js')); ?>"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="<?php echo e(url('/home')); ?>">Jackson</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="#!">Settings</a></li>
                        <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="#!">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link <?php if(!empty($data['dashboard'])): ?><?php echo e('active'); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" href="<?php echo e(url('/home')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            <a class="nav-link <?php if(!empty($data['item_masuk'])): ?><?php echo e('active'); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" href="<?php echo e(url('/in')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-in"></i></div>
                                Item Masuk
                            </a>
                            <a class="nav-link <?php if(!empty($data['item_keluar'])): ?><?php echo e('active'); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" href="<?php echo e(url('/out')); ?>">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out"></i></div>
                                Item Keluar
                            </a>
                            
                            <a class="nav-link <?php if(!empty($data['menu_active'])): ?><?php echo e(''); ?><?php else: ?><?php echo e('collapsed'); ?><?php endif; ?> " href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="<?php if(!empty($data['active'])): ?><?php echo e('true'); ?><?php else: ?><?php echo e('false'); ?><?php endif; ?>" aria-controls="collapseLayouts">
                                <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                                Recap Scan Order
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse <?php if(!empty($data['menu_active'])): ?><?php echo e('show'); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link <?php if(!empty($data['item'])): ?><?php echo e('active'); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" href="<?php echo e(url('/item')); ?>">Item Master</a>
                                    <a class="nav-link <?php if(!empty($data['item_scan'])): ?><?php echo e('active'); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" href="<?php echo e(url('/item/scan')); ?>">Item Scan</a>
                                    <a class="nav-link <?php if(!empty($data['item_stok'])): ?><?php echo e('active'); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>" href="<?php echo e(url('/item/stok')); ?>">Laporan Stok SO</a>
                                </nav>
                            </div>
                            
                            
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-xl-6">
                                <?php echo e(auth()->user()->name); ?>

                            </div>
                            <div class="col-md-6 col-sm-6 col-xl-6">
                                <a href="<?php echo e(url('/dologout')); ?>" class="btn btn-danger btn-sm">Logout <i class="fas fa-window-close"></i></a>
                            </div>
                        </div>


                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
<?php /**PATH C:\xampp\htdocs\scann_gudang_jkt\resources\views/layout/head.blade.php ENDPATH**/ ?>