<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; Sinar Terang Sejahtera IT 2023</div>
            
        </div>
    </div>
</footer>
</div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\scann_gudang_jkt\resources\views/layout/foot.blade.php ENDPATH**/ ?>