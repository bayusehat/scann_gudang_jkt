<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($data['content']): ?>
    <?php echo e(view($data['content'],$data)); ?>

<?php else: ?>
    <?php echo e(view('notfound')); ?>

<?php endif; ?>
<?php echo $__env->make('layout.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH C:\xampp\htdocs\scann_gudang_jkt\resources\views/layout/index.blade.php ENDPATH**/ ?>